enum Category {
  Work = 0,
  Life = 1,
  Study = 2
}

export default Category;